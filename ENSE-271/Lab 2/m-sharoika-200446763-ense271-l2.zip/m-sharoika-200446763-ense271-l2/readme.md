# SHAROIKA TUTORING
## sharoika.ca

The sitemap.png & asset-inventory.ods & and readme.md are all put together into this folder.

The sitemap.png shows a visutal representation of the sites webpages, while the asset-invetory goes further indepth on aspects of it.

This was an analysis of my tutoring companies website and I am going to use it to improve where I saw it lacking.
