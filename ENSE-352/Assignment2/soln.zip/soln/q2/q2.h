// -*- c++ -*-
#include <stdint.h>
#include <limits.h>
int16_t saturating_add(int16_t x, int16_t y);
