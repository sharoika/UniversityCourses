// -*- c++ -*-
#include <stdint.h>
#include <limits.h>
int64_t minimum_2s_comp_bits(int64_t x);

