// -*- c++ -*-
#include <limits.h>             // for INT_MIN, etc.
unsigned rotate_left(unsigned x, int n);
