// -*- c++ -*_
#include <limits.h>              // for INT_MIN, etc

int a(int x);
int b(int x);
int c(int x);
int d(int x);
